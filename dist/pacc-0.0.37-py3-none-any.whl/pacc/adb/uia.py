class UIAutomator:
    def __init__(self):
        pass

    def click(self, resourceID):
        pass

    def getBounds(self, resourceID):
        pass
