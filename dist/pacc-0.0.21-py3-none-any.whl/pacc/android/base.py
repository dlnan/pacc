class AndroidBase:
    def __init__(self, deviceName):
        self.deviceName = deviceName
