def average(*args):
    return int(sum(args) / len(args))
