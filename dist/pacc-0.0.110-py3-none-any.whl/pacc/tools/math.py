def average(*args):
    return sum(args) / len(args)
