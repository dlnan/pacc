attendance = '[195,1299][885,1440]'  # 财富页面签到
cashCoupons = '[672,351][858,459]'  # 可用抵用金（张）
goldCoins = '[-1,351][-1,459]'  # 金币收益
closeInviteFriendsToMakeMoney = '[483,1563][597,1674]'  # 关闭邀请好友赚更多
closeCongratulations = '[78,405][174,501]'  # 关闭恭喜获得好友看视频奖励
