from .base import AndroidBase


class Android(AndroidBase):
    
    def getIP(self, ):
        pass