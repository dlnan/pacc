# 返回
HomeActivity = 'com.kuaishou.nebula/com.yxcorp.gifshow.HomeActivity'  # 主界面
PhotoDetailActivity = 'com.kuaishou.nebula/com.yxcorp.gifshow.detail.PhotoDetailActivity'  # 直播
MiniAppActivity0 = 'com.kuaishou.nebula/com.mini.app.activity.MiniAppActivity0'  # 小程序
TopicDetailActivity = 'com.kuaishou.nebula/com.yxcorp.plugin.tag.topic.TopicDetailActivity'  # 每日书单
UserProfileActivity = 'com.kuaishou.nebula/com.yxcorp.gifshow.profile.activity.UserProfileActivity'  # 用户主页
AdYodaActivity = 'com.kuaishou.nebula/com.yxcorp.gifshow.ad.webview.AdYodaActivity'  # 广告
# 重启
KRT1Activity = 'com.kuaishou.nebula/com.kwai.frog.game.engine.adapter.engine.base.KRT1Activity'  # 拯救小金鱼游戏
