class UIAutomator:
    def __init__(self, IP):
        """
        :param IP: the IPv4 address of device
        """
        self.IP = IP

    def click(self, resourceID):
        pass

    def getBounds(self, resourceID):
        pass
