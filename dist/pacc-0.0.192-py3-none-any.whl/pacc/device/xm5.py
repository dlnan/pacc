from .device import Device


class XM5(Device):
    pass
