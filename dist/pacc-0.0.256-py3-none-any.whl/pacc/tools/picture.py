from PIL import Image


def optimizePic(filePath, scale=0.25):
    img = Image.open(filePath)
    img = img.resize((int(img.size[0] * scale), int(img.size[1] * scale)))
    img = img.convert("L")
    img.save(filePath)
