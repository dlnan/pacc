class Config:
    debug = False

    @classmethod
    def setDebug(cls, debug):
        cls.debug = debug
