root = 'com.ss.android.ugc.aweme/'


class Activity:
    SplashActivity = root + 'com.ss.android.ugc.aweme.splash.SplashActivity'  # 抖音程序入口
    LivePlayActivity = root + 'com.ss.android.ugc.aweme.live.LivePlayActivity'  # 直播
    FollowRelationTabActivity = root + 'com.ss.android.ugc.aweme.following.ui.FollowRelationTabActivity'  # 关注列表

